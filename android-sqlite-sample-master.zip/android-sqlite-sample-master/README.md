# android-sqlite-sample
Sample project showing how to use sqlite in an android app

Creates a single table in a database. Shows "SELECT", "UPDATE" and "DELETE".
